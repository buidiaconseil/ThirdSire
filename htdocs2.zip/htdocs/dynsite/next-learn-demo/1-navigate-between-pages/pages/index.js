// This is the Link API
import Link from 'next/link'

const Index = () => (
  <div>
    <Link href="/about">
      <a>About Page</a>
    </Link>
    <p>Hello Next.js</p>
    <Link href="/about" title="About Page">
      <a>About Page</a>
    </Link>
  </div>
)

export default Index