const Index = () => (
  <div>
    <p>Hello Next.js</p>
  </div>
)

export default Index